package main

import (
	"fmt"
	"github.com/gohouse/gorose"
)

// ./artisan make (create_users_table)	生成迁移:创建用户表
// ./artisan migrate					运行迁移
// ./artisan rollback					回滚迁移
// ./artisan reset						回滚所有的应用迁移
// ./artisan refresh					在单个命令中回滚 & 迁移
// ./artisan fresh						删除所有表 & 迁移

var conn *gorose.Connection
var err error

func init() {
}
func main() {
	conn,err = gorose.Open("mysql", "gcore:gcore@tcp(192.168.200.248:3306)/test?charset=utf8")
	fmt.Println(conn,err)
}