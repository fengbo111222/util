package converter

const VERSION  = "0.0.3"

const VERSION_TEXT = "convert of mysql schema to golang struct"

const LIB_IMG = ``
